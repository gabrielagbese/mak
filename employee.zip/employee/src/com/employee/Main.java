package com.employee;

public class Main {

    public static void main(String[] args) {
        employee mark = new employee("Mark",500000,19);

        mark.print_sal();
        mark.increaseSalary();
        mark.print_sal();

    }
}
