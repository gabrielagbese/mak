package com.employee;

public class employee {
    String name;
    private int sal;
    int age;

    public  employee(String n, int s, int a){
        name = n;
        sal = s;
        age = a;
    }

    public void increaseSalary(){
        sal = sal+2000000;
    }

    public void print_sal(){
        System.out.println(sal);
    }
}
